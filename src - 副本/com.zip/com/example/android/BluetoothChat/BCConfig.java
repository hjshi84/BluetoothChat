package com.example.android.BluetoothChat;

/**
 * Created with IntelliJ IDEA.
 * User: hjshi84
 * Date: 13-12-11
 * Time: 下午6:31
 * To change this template use File | Settings | File Templates.
 */
public class BCConfig {
    //config class

    //draw picture
    int drawInterval=1000;
    int[] drawNode={0,1};
    boolean drawFall=true;
    boolean drawGate=true;
    boolean drawAcc=true;
    boolean drawGyro=false;


    //warn config
    int GateDetect=0;
    boolean warnEnable=true;
    boolean sMs=false;
    boolean telPhone=false;
    boolean gPs=false;

    //user info

}
