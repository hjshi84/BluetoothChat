package com.example.android.BluetoothChat;

import android.opengl.GLSurfaceView;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.IntBuffer;

/**
 * Created with IntelliJ IDEA.
 * User: hjshi84
 * Date: 13-12-30
 * Time: 下午10:11
 * To change this template use File | Settings | File Templates.
 */
public class MotionRender implements GLSurfaceView.Renderer{
    float rotateQuad;
    int one=0x10000;

    int [] colorArray = {
            one,0,0,one,
            0,one,0,one,
            0,0,one,one,
            0,0,0,one,
    };
    int [] triggerArray ={
            0,one,0,
            -one,-one,0,
            one,-one,0
    };
    int []  quaterArray = {
            one,one,0,
            -one,one,0,
            one,-one,0,
            -one,-one,0
    };

    public Buffer bufferUtil(int []arr){
        IntBuffer mBuffer ;

        //先初始化buffer,数组的长度*4,因为一个int占4个字节
        ByteBuffer qbb = ByteBuffer.allocateDirect(arr.length * 4);
        //数组排列用nativeOrder
        qbb.order(ByteOrder.nativeOrder());

        mBuffer = qbb.asIntBuffer();
        mBuffer.put(arr);
        mBuffer.position(0);

        return mBuffer;
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        // TODO Auto-generated method stub

        // 清除屏幕和深度缓存
        gl.glClear(GL10.GL_COLOR_BUFFER_BIT | GL10.GL_DEPTH_BUFFER_BIT);
        // 重置当前的模型观察矩阵

        /***********************/
        /* 渲染正方形 */
        // 重置当前的模型观察矩阵
        gl.glLoadIdentity();

        // 左移 1.5 单位，并移入屏幕 6.0
        gl.glTranslatef(-2.0f, 0.0f, 0.0f);

        // 设置当前色为蓝色
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
        gl.glColorPointer(4, GL10.GL_FIXED, 0, bufferUtil(colorArray));
        //设置旋转
        //gl.glRotatef(rotateQuad, 0.0f, 0.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(0).IMUX, 1.0f, 0.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(0).IMUY, 0.0f, 1.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(0).IMUZ, 0.0f, 0.0f, 1.0f);
        //设置和绘制正方形
        gl.glVertexPointer(3, GL10.GL_FIXED, 0, bufferUtil(quaterArray));
        gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);

        //绘制正方形结束
        gl.glFinish();

        gl.glLoadIdentity();

        // 左移 1.5 单位，并移入屏幕 6.0
        gl.glTranslatef(2.0f, 0.0f, 0.0f);

        // 设置当前色为蓝色
        gl.glEnableClientState(GL10.GL_COLOR_ARRAY);
        gl.glColorPointer(4, GL10.GL_FIXED, 0, bufferUtil(colorArray));
        //设置旋转
        //gl.glRotatef(rotateQuad, 0.0f, 0.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(1).IMUX, 1.0f, 0.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(1).IMUY, 0.0f, 1.0f, 0.0f);
        gl.glRotatef(BluetoothChat.myIMU.get(1).IMUZ, 0.0f, 0.0f, 1.0f);
        //设置和绘制正方形
        gl.glVertexPointer(3, GL10.GL_FIXED, 0, bufferUtil(quaterArray));
        gl.glDrawArrays(GL10.GL_TRIANGLE_STRIP, 0, 4);

        //绘制正方形结束
        gl.glFinish();


        //取消顶点数组
        gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);

        //改变旋转的角度
        rotateQuad -= 0.5f;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int width, int height) {
        // TODO Auto-generated method stub

        float ratio = (float) width / height;
        //设置OpenGL场景的大小
        gl.glViewport(0, 0, width, height);
        //设置投影矩阵
        gl.glMatrixMode(GL10.GL_PROJECTION);
        //重置投影矩阵
        gl.glLoadIdentity();
        // 设置视口的大小
        gl.glFrustumf(-ratio, ratio, -1, 1, 1, 10);
        gl.glTranslatef(0,0,-4);
        // 选择模型观察矩阵
        gl.glMatrixMode(GL10.GL_MODELVIEW);
        // 重置模型观察矩阵
        gl.glLoadIdentity();

    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // TODO Auto-generated method stub
        // 启用阴影平滑
        gl.glShadeModel(GL10.GL_SMOOTH);

        // 黑色背景
        gl.glClearColor(0, 0, 0, 0);

        // 设置深度缓存
        gl.glClearDepthf(1.0f);
        // 启用深度测试
        gl.glEnable(GL10.GL_DEPTH_TEST);
        // 所作深度测试的类型
        gl.glDepthFunc(GL10.GL_LEQUAL);

        // 告诉系统对透视进行修正
        gl.glHint(GL10.GL_PERSPECTIVE_CORRECTION_HINT, GL10.GL_FASTEST);
    }
}
